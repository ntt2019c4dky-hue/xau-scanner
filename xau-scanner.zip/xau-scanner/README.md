# XAU/USD ICT Liquidity Scanner

Web app giám sát tín hiệu ICT Liquidity Swing cho XAUUSD — Phiên Á, Âu, Mỹ.

## Tính năng
- ⚡ Auto-scan Liquidity Sweep + FVG + iFVG confirmation
- 📈 Chart với TradingView Lightweight Charts + signal markers
- 📐 Risk/Reward Calculator (lot size, dollar risk, R:R ratio)
- 📋 Signal History lưu bền vững (localStorage)
- 📅 Lịch kinh tế ForexFactory (không cần API key)
- 🔔 Browser notifications khi có signal

## Deploy lên Vercel (5 phút)

### Bước 1 — Tạo GitHub repo
1. Vào [github.com](https://github.com) → New repository
2. Đặt tên: `xau-scanner` → Create
3. Upload toàn bộ thư mục này lên repo

### Bước 2 — Deploy Vercel
1. Vào [vercel.com](https://vercel.com) → Sign up bằng GitHub
2. New Project → Import repo `xau-scanner`
3. Nhấn Deploy — xong!

### Bước 3 — Dùng thôi
- Vercel cho 1 link cố định kiểu `xau-scanner-xxx.vercel.app`
- Mở trên điện thoại, vào Settings → thêm API key Twelve Data
- Nhấn ▶ Bắt đầu

## API Keys cần thiết
- **Twelve Data** (bắt buộc): [twelvedata.com](https://twelvedata.com) — free 800 req/ngày
- **ForexFactory calendar**: không cần key, backend tự fetch

## Cấu trúc project
```
├── api/
│   ├── candles.js     # Proxy Twelve Data (bypass CORS)
│   └── calendar.js    # Fetch ForexFactory (bypass CORS)
├── public/
│   ├── index.html     # Frontend chính
│   └── manifest.json  # PWA manifest
└── vercel.json        # Cấu hình routes
```

## Giờ phiên (giờ VN UTC+7)
- 🔵 Phiên Á (Tokyo): 07:00 – 13:00
- 🟢 Phiên Âu (London): 13:00 – 21:00  
- 🟡 Phiên Mỹ (New York): 19:00 – 03:00
