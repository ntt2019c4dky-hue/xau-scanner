export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  const { tf = '15min', apikey, size = '150' } = req.query;
  if (!apikey) return res.status(400).json({ error: 'Missing apikey' });
  try {
    const url = `https://api.twelvedata.com/time_series?symbol=XAU/USD&interval=${tf}&outputsize=${size}&apikey=${apikey}`;
    const r = await fetch(url);
    const data = await r.json();
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
