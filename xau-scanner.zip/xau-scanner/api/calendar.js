export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  try {
    const [thisWeek, nextWeek] = await Promise.all([
      fetch('https://nfs.faireconomy.media/ff_calendar_thisweek.json', {
        headers: { 'User-Agent': 'Mozilla/5.0' }
      }).then(r => r.json()),
      fetch('https://nfs.faireconomy.media/ff_calendar_nextweek.json', {
        headers: { 'User-Agent': 'Mozilla/5.0' }
      }).then(r => r.json()),
    ]);
    const all = [...(Array.isArray(thisWeek) ? thisWeek : []), ...(Array.isArray(nextWeek) ? nextWeek : [])];
    res.json(all);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
